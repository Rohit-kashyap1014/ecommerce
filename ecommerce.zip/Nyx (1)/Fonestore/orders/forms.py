from django import forms
from .models import Order
from login.models import *
from login.forms import UserForm

UserForm()



COUNTRY_CHOICES = (
    ('COUNTRY','Country'),
    ('AUSTRALIA','Australia'),
    ('UNITED STATES','United States'),
    ('UNITED KINGDOM','United Kingdom')
    )

STATE_CHOICES = (
    ('STATE','State'),
    ('MELBOURNE','Melbourne'),
    ('DHAKA','Dhaka'),
    ('NEW YORK','New York'),
    ('LONDON','London')
    )

CITY_CHOICES = (
    ('CITY','City'),
    ('VICTORIYA','Victoriya'),
    ('CHITTAGONG','Chittagong'),
    ('BOTSON','Botson'),
    ('CAMBRIDGE','Cambridge'),
    )

class OrderCreateForm(forms.ModelForm):
    name = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder': 'Your Name Here...'}))
    email = forms.EmailField(label='',widget=forms.TextInput(attrs={'placeholder': 'Email address here...'}))
    phone = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder': 'Phone here...'}))
    company = forms.CharField(label='',widget=forms.TextInput(attrs={
        'placeholder': 'Company Name Here...',
        'class': 'custom-select'
        }))
    country = forms.ChoiceField(label='',choices=COUNTRY_CHOICES)
    state = forms.ChoiceField(label='',choices=STATE_CHOICES)
    city = forms.ChoiceField(label='',choices=CITY_CHOICES)
    billingaddress = forms.CharField(label='',widget=forms.Textarea(attrs={'placeholder':'enter your biling address'}))
    shippingaddress = forms.CharField(label='',widget=forms.Textarea(attrs={'placeholder':'enter your shipping address'}))
    class Meta:
        model = Order
        fields = ['name', 'email', 'phone', 'company', 'country', 'state','city','billingaddress','shippingaddress']
