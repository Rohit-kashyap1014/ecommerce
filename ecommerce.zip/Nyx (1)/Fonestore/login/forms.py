from django import forms
from .models import UserProfileInfo
from django.contrib.auth.models import User

COUNTRY_CHOICES = (
    ('COUNTRY','Country'),
    ('AUSTRALIA','Australia'),
    ('UNITED STATES','United States'),
    ('UNITED KINGDOM','United Kingdom')
    )

STATE_CHOICES = (
    ('STATE','State'),
    ('MELBOURNE','Melbourne'),
    ('DHAKA','Dhaka'),
    ('NEW YORK','New York'),
    ('LONDON','London')
    )

CITY_CHOICES = (
    ('CITY','City'),
    ('VICTORIYA','Victoriya'),
    ('CHITTAGONG','Chittagong'),
    ('BOTSON','Botson'),
    ('CAMBRIDGE','Cambridge'),
    )

class UserForm(forms.ModelForm):
    firstname = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder': 'First Name...'}))
    lastname = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder': 'Last Name...'}))
    email = forms.EmailField(label='',widget=forms.TextInput(attrs={'placeholder': 'Email address here...'}))
    phone = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder': 'Phone here...'}))
    company = forms.CharField(label='',widget=forms.TextInput(attrs={
        'placeholder': 'Company Name Here...',
        'class': 'custom-select'
        }))
    country = forms.ChoiceField(label='',choices=COUNTRY_CHOICES, widget = forms.Select(attrs={
        'style': 'width: 100% !important; position = relative !important;'
        }))
    state = forms.ChoiceField(label='',choices=STATE_CHOICES, widget = forms.Select(attrs={
        'style': 'width: 100% !important; position = absolute !important;'
        }))
    city = forms.ChoiceField(label='',choices=CITY_CHOICES, widget = forms.Select(attrs={
        'style': 'width: 100% !important; position = relative !important;'
        }))
    billingaddress = forms.CharField(label='',widget=forms.Textarea(attrs={'placeholder':'enter your billing address'}))
    shippingaddress = forms.CharField(label='',widget=forms.Textarea(attrs={'placeholder': 'enter your shipping address'}))
    username = forms.CharField(label='',widget=forms.TextInput(attrs={'placeholder': 'Username...'}))
    password = forms.CharField(label='',widget=forms.PasswordInput(attrs={'placeholder': 'Password...'}))
    class Meta():
        model = User
        fields = ['username','password','firstname', 'lastname', 'email', 'phone', 'company', 'country', 'state','city','billingaddress','shippingaddress']
