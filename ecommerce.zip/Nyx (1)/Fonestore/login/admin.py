from django.contrib import admin
from login.models import UserProfileInfo, User

class UserAdmin(admin.ModelAdmin):
    list_display = ['firstname','lastname', 'email', 'phone', 'company', 'country', 'state','city','billingaddress','shippingaddress']

admin.site.register(UserProfileInfo, UserAdmin)
