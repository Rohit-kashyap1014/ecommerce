# dappx/urls.py
from django.conf.urls import url
from login import views
# from shop import views as vw
# SET THE NAMESPACE!
app_name = 'login'
# Be careful setting the name to just /login use userlogin instead!
urlpatterns=[
    url(r'^$',views.product_list, name='product_list'),
    # url(r'^(?P<category_slug>[-\w]+)/$', views.product_list, name='product_list_by_category'),
    url(r'^register/$',views.register,name='register'),
    url(r'^user_login/$',views.user_login,name='user_login'),
]
