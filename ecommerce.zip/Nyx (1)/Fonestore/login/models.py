from django.db import models
from django.contrib.auth.models import User

# Create your models here.

COUNTRY_CHOICES = (
    ('COUNTRY','Country'),
    ('AUSTRALIA','Australia'),
    ('UNITED STATES','United States'),
    ('UNITED KINGDOM','United Kingdom')
    )

STATE_CHOICES = (
    ('STATE','State'),
    ('MELBOURNE','Melbourne'),
    ('DHAKA','Dhaka'),
    ('NEW YORK','New York'),
    ('LONDON','London')
    )

CITY_CHOICES = (
    ('CITY','City'),
    ('VICTORIYA','Victoriya'),
    ('CHITTAGONG','Chittagong'),
    ('BOTSON','Botson'),
    ('CAMBRIDGE','Cambridge'),
    )
class UserProfileInfo(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    firstname = models.CharField(max_length=60)
    lastname = models.CharField(max_length=60)
    email = models.EmailField()
    phone = models.CharField(max_length=60)
    company = models.CharField(max_length=60)
    country = models.CharField(max_length=15,choices=COUNTRY_CHOICES, default='COUNTRY')
    state = models.CharField(max_length=15 ,choices=STATE_CHOICES, default='STATE')
    city = models.CharField(max_length=15 ,choices=CITY_CHOICES, default='CITY')
    billingaddress = models.CharField(max_length=150)
    shippingaddress = models.CharField(max_length=150)
    def __str__(self):
        return self.user.userename

